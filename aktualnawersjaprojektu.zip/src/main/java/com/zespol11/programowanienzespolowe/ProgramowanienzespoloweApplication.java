package com.zespol11.programowanienzespolowe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProgramowanienzespoloweApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProgramowanienzespoloweApplication.class, args);
	}

}
