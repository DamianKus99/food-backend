package com.zespol11.programowanienzespolowe.userRegistration.appuser;

public enum UserRole {
    USER,
    ADMIN,
    COOK
}
